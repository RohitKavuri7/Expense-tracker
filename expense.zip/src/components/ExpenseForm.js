import React, { useState, useEffect } from 'react';
import { db, storage } from '../firebaseConfig';  // Import Firebase storage
import { collection, addDoc, doc, getDoc } from 'firebase/firestore';  // For Firestore
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';  // For storing receipts
import { useNavigate } from 'react-router-dom';
import Tesseract from 'tesseract.js';  // Import Tesseract.js for OCR
import './ExpenseForm.css';

const ExpenseForm = ({ user }) => {
  const [name, setName] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('');
  const [customCategory, setCustomCategory] = useState('');
  const [receipt, setReceipt] = useState(null);  // For storing the uploaded receipt image
  const [ocrText, setOcrText] = useState('');    // To store OCR result
  const [budget, setBudget] = useState(null);    // Store budget for user

  const predefinedCategories = ['Food', 'Transport', 'Utilities', 'Entertainment', 'Other'];

  const navigate = useNavigate();

  // Fetch the user's budget from Firestore on component load
  useEffect(() => {
    const fetchBudget = async () => {
      const docRef = doc(db, 'budgets', user.uid);  // Assume each user has a budget document
      const budgetSnap = await getDoc(docRef);
      if (budgetSnap.exists()) {
        setBudget(budgetSnap.data().budget);
      }
    };
    fetchBudget();
  }, [user.uid]);

  // Handle receipt image upload
  const handleReceiptUpload = (e) => {
    const file = e.target.files[0];
    setReceipt(file);
    if (file) {
      processReceipt(file);  // Start OCR processing after the image is uploaded
    }
  };

  // Process receipt using Tesseract.js for OCR
  const processReceipt = (file) => {
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const imageDataUrl = event.target.result;
        Tesseract.recognize(
          imageDataUrl,
          'eng',  // English language
          { logger: (m) => console.log(m) }  // Logs OCR progress
        ).then(({ data: { text } }) => {
          setOcrText(text);  // Set OCR result text
          extractExpenseData(text);  // Auto-fill form with OCR data
        });
      };
      reader.readAsDataURL(file);
    }
  };

  // Extract and auto-fill the expense form fields from the OCR text
  const extractExpenseData = (text) => {
    console.log('OCR Extracted Text:', text);
  
    // Split the text into lines for easier processing
    const lines = text.split('\n').map(line => line.trim()).filter(line => line.length > 0);
  
    // Basic heuristics to find the amount in the extracted text
    const amountRegex = /\$?\d+(?:,\d{3})*(?:\.\d{2})?/; // Matches dollar amounts
    for (let line of lines) {
      const match = line.match(amountRegex);
      if (match) {
        setAmount(match[0].replace('$', '')); // Set the amount field
        break;
      }
    }
  
    // Attempt to set the name and category from the extracted text (simple heuristics)
    if (lines.length > 0) {
      setName(lines[0]); // Use the first line as the name
    }
    if (lines.length > 1) {
      setCategory(predefinedCategories.includes(lines[1]) ? lines[1] : 'Other'); // Use the second line as category if valid
    }
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!name || !amount || !category) {
      alert('Please fill out all required fields.');
      return;
    }

    const expenseData = {
      name,
      amount: parseFloat(amount),
      category: category === 'Custom' ? customCategory : category,
      date: new Date().toISOString(),
      uid: user.uid,
    };

    try {
      let receiptURL = null;
      // Upload receipt if it exists
      if (receipt) {
        const receiptRef = ref(storage, `receipts/${user.uid}/${receipt.name}`);
        await uploadBytes(receiptRef, receipt);
        receiptURL = await getDownloadURL(receiptRef);
      }
      // Save expense data to Firestore
      await addDoc(collection(db, 'expenses'), { ...expenseData, receiptURL });
      alert('Expense added successfully!');
      navigate('/expenses');  // Redirect to expense list
    } catch (error) {
      console.error('Error adding expense:', error);
      alert('Failed to add expense: ' + error.message);
    }
  };

  return (
    <div className="expense-form">
      <h2>Add Expense</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Expense Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
        />
        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          required
        >
          <option value="">Select Category</option>
          {predefinedCategories.map((cat, index) => (
            <option key={index} value={cat}>{cat}</option>
          ))}
          <option value="Custom">Custom</option>
        </select>
        {category === 'Custom' && (
          <input
            type="text"
            placeholder="Custom Category"
            value={customCategory}
            onChange={(e) => setCustomCategory(e.target.value)}
          />
        )}
        <input type="file" accept="image/*" onChange={handleReceiptUpload} />
        {ocrText && <p>Extracted Text: {ocrText}</p>} {/* Display OCR result */}
        <button type="submit">Add Expense</button>
      </form>
    </div>
  );
};

export default ExpenseForm;
